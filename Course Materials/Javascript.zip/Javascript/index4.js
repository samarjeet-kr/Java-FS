// function hoisting - If we call a function before it's declaration then it is known as function hoisting
// pure function - It can be hoisted
show()
show()
show()
function show() {
    console.log("Hello World!")
}

// variable type function - It cannot be hoisted
let greet = function() {
    console.log("Hello World Again!")
}
greet()
greet()
greet()