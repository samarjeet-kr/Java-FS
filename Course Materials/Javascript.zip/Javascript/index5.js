// parameters - When a function is declared then the local variable declared inside function's body is known as parameter.

let greet = function(name, age) { // parameters
    console.log(`Hello my name is ${name} and age is ${age}`)
}
greet()

// assigning default values
let greet1 = function(name="Mario", age=30) { // parameters
    console.log(`Hello my name is ${name} and age is ${age}`)
}
greet1()

let greet2 = function(name, age) { // parameters
    console.log(`Hello my name is ${name} and age is ${age}`)
}
greet2("Shaun", 40) // arguments
greet2("Yoshi", 50) // arguments

// variable type function has two types
// 1. Regular function 
let add = function(a, b) {
    return a + b
}
console.log("Addition is " + add(20, 30))

// 2. Arrow function
let sub = (a, b) => {
    return a - b
}
console.log("Subtraction is " + sub(50, 30))

// difference b/w regular and arrow function 
let areaRectangle = function(height, width) {
    return height * width
}
console.log("Area of rectangle is " + areaRectangle(7, 8))

let areaCircle = (radius) => Math.PI * radius ** 2 // since it is a single line statement, so the total statement will be returned without return keyword
console.log("Area of circle is " + Math.round(areaCircle(13)));

// If a function has no name then it is called as anonymous function
(function() {
    console.log("Hello World!")
}())

// higher order function - If a function is returning multiple function at a single time then the most outer function or parent function is known as higher order function.
let mult1 = (a) => {
    return mult2 = (b) => {
        return mult3 = (c) => {
            return a * b * c
        }
    }
}
let res1 = mult1(5)
let res2 = mult2(6)
let res3 = mult3(7)
console.log(res3)

// filter method
let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
console.log(arr.filter((a) => a % 2 === 0))

// map method - maninly used to map object's keys into jsx 
console.log(arr.map((a) => a * 10))