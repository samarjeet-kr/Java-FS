let display = {
    add: function(a, b) {
        return a + b
    },
    mult: function(a, b) {
        return a * b
    },
    blogs: [
        {
            title: "JS", description: "JavaScript"
        },
        {
            title: "JPA", description: "Java Persistance API"
        },
        {
            title: "PHP", description: "Hypertext Pre-Processor"
        }
    ],
    logBlogs: function() {
        this.blogs.forEach(blog => {
            console.log(`Blog Title: ${blog.title} and Description: ${blog.description}`)
        })
    }
}
let a = 10
let b = 5
console.log(display.add(a, b))
console.log(display.mult(a, b))
console.log(display.blogs)
display.logBlogs()