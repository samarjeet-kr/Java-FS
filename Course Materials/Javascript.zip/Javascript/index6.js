let arr = [1, 2, 3, 4, 5]
console.log(arr[2])

let user = {
    // key : values
    username: "Mario",
    age: 50,
    height: Symbol("5.8ft"),
    isAvailable: true
}
console.log(user)
console.log(typeof(user))
console.log(user["username"])
user["username"] = "Shaun"
console.log(user["username"])
console.log(user.age)
user.age = 60
console.log(user.age)