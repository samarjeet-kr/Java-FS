let str = "abc@learnjs"

console.log(str[3])
console.log(str.length)
console.log(str.toLowerCase())
console.log(str.toUpperCase())
console.log(str.includes('@'))
console.log(str.includes('!'))
console.log(str.replace('@', '#'))
console.log(str.slice(3, 9)) 

let a = 100
// loose comparison
console.log(a == "100")
console.log(a != "100")
// strict comparison
console.log(a === "100")
console.log(a !== "100")

let age = 50
let firstName = "Mario"
let lastName = "Jackson"
// concatination in normal way
let res = "Hello, my name is " + firstName + " " + lastName + ", and my age is " +age
// concatination using string template
console.log(res)
let res1 = `Hello, my name is ${firstName} ${lastName}, and my age is ${age}`
console.log(res1)