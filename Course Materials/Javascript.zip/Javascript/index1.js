// let - It will not provide block scoping
let a = 100
{
    let a = 50
    console.log(a)
}
console.log(a)

// var - It will provide block scoping
var b = 200
{
    var b = 20
    console.log(b) // 20
}
console.log(b) // 20

// const - only constants, we cannot re-initialize.
const c = 300
console.log(c)

// Datatypes in js - null Number Bigint Boolean Symbol String undefined