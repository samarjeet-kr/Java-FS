package com.mario.main;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mario.main.dao.EmployeeDAO;
import com.mario.main.entity.Employee;

@SpringBootApplication
public class SpringBootProjectJdbcCrudApplication implements CommandLineRunner{
	
	@Autowired
	private EmployeeDAO employeeDAO;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectJdbcCrudApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Create Employee
//		Employee emp1 = new Employee(3, "Shaun", "Barrackpore");
//		boolean status = employeeDAO.insertEmployee(emp1);
//		if(status) {
//			System.out.println("Employee added");
//		} else {
//			System.out.println("Employee not added");
//		}
		
		// Select Single Employee
//		Employee emp = employeeDAO.selectEmployee(1L);
//		System.out.println("Name: "+ emp.getName());
//		System.out.println("Address: "+ emp.getAddress());
		
		// Update Employee
//		Employee emp = new Employee();
//		emp.setId(1L);
//		emp.setName("Luigi");
//		emp.setAddress("Asansol");
//
//		int count = employeeDAO.updateEmployee(emp);
//		if (count > 0) {
//		    System.out.println("Employee updated successfully.");
//		} else {
//		    System.out.println("No employee found with the given ID.");
//		}
		
		// Delete Employee
//		int count = employeeDAO.deleteEmployee(1L);
//		if (count > 0) {
//		    System.out.println("Employee deleted successfully.");
//		} else {
//		    System.out.println("No employee found with the given ID.");
//		}
		
		// Select All Employees
//		List<Employee> list = employeeDAO.getALLEmployee();
//		for(Employee emp : list) {
//			System.out.println("Name: "+ emp.getName());
//			System.out.println("Address: "+ emp.getAddress());
//			System.out.println("\n");
//		}
		
	}

}
