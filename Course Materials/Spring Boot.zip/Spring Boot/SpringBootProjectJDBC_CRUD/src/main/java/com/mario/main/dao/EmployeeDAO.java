package com.mario.main.dao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mario.main.entity.Employee;
import com.mario.main.mapper.EmployeeRowMapper;

@Repository
public class EmployeeDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public boolean insertEmployee(Employee employee) {
		boolean status = false;
		try {
			String INSERT_SQL_QUERY = "INSERT INTO employee(id, name, address) VALUES(?, ?, ?)";
			int count = jdbcTemplate.update(INSERT_SQL_QUERY, employee.getId(), employee.getName(), employee.getAddress());
			status = count > 0;
		} catch(Exception e) {
			status = false;
			e.printStackTrace();
		}
		return status;
	}

	public Employee selectEmployee(long id) {
        String SELECT_SQL_QUERY = "SELECT * FROM employee WHERE id = ?";
        return jdbcTemplate.queryForObject(SELECT_SQL_QUERY, new EmployeeRowMapper(), id);
    }
	
	public int deleteEmployee(long id) {
	    String DELETE_SQL_QUERY = "DELETE FROM employee WHERE id = ?";
	    return jdbcTemplate.update(DELETE_SQL_QUERY, id);
	}

	public int updateEmployee(Employee employee) {
	    String UPDATE_SQL_QUERY = "UPDATE employee SET name = ?, address = ? WHERE id = ?";
	    return jdbcTemplate.update(UPDATE_SQL_QUERY, employee.getName(), employee.getAddress(), employee.getId());
	}
	
	public List<Employee> getALLEmployee() {
		String SELECT_ALL_SQL_QUERY = "SELECT * FROM employee";
		return jdbcTemplate.query(SELECT_ALL_SQL_QUERY, new EmployeeRowMapper());
	}
}
