package com.mario.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectJdbcCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
