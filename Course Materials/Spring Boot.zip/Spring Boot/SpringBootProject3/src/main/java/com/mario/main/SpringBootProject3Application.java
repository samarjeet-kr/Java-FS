package com.mario.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import com.mario.main.beans.Student;

@SpringBootApplication
public class SpringBootProject3Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProject3Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		stdBean1().display();
		stdBean2().display();
	}
	
	@Bean	
	public Student stdBean1() {
		return new Student("Mario", 1, "Kolkata");
	}
	
	@Bean	
	public Student stdBean2() {
		return new Student("Luigi", 2, "Pune");
	}

}
