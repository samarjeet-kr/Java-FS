package com.mario.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProject1Application {

	public static void main(String[] args) {
		System.out.println("App Started");
		SpringApplication.run(SpringBootProject1Application.class, args);
		System.out.println("App Finished");
	}

}
