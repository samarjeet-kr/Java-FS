package com.mario.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
