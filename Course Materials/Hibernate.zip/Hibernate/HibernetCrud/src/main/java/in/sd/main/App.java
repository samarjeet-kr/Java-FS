package in.sd.main;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import in.sd.entities.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	Employee emp1 = new Employee();
//    	emp1.setId(1);
//    	emp1.setEname("Mario");
//    	emp1.setEsal(50000);
//    	emp1.setAddress("Kolkata");
    	
    	Employee emp3 = new Employee();
    	emp3.setId(1);
    	emp3.setEname("Shaun");
    	emp3.setEsal(70000);
    	emp3.setAddress("Gujrat");
    	
    	
        Configuration cfg = new Configuration();
        cfg.configure("/in/sd/config/hibernate.cfg.xml");
        
        SessionFactory sessionFactory = cfg.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        
        // Create
//        try {
//        	session.save(emp3);
//            transaction.commit();
//            System.out.print("Employee added");
//        } catch(Exception e) {
//        	transaction.rollback();
//        	e.printStackTrace();
//        	System.out.print("Error occured Employee not added");
//        }
        
        
        // Read
//        try {
//        	Employee emp = session.get(Employee.class, 2L);
//        	
//        	if(emp != null) {
//        		System.out.println("Id: " + emp.getId());
//            	System.out.println("Name: " + emp.getEname());
//            	System.out.println("Salary: " + emp.getEsal());
//            	System.out.println("Address: " + emp.getAddress());
//        	} else {
//        		System.out.println("Employee not found");
//        	}
//        } catch(Exception e) {
//        	e.printStackTrace();
//        }
        
        // Update
//	    try {
//	    	Employee emp = session.get(Employee.class, 5L);
//	    	emp.setAddress("Pune");
//	    	emp.setEsal(90000);
//	    	session.update(emp);
//	        transaction.commit();
//	        System.out.print("Employee updated successfully");
//	    } catch(Exception e) {
//	    	transaction.rollback();
//	    	e.printStackTrace();
//	    	System.out.print("Error occured Employee not updated");
//	    }
        
        // Delete
	    try {
	    	Employee emp = new Employee();
	    	emp.setId(4L);
	    	session.delete(emp);
	    	
	        transaction.commit();
	        System.out.print("Employee deleted successfully");
	    } catch(Exception e) {
	    	transaction.rollback();
	    	e.printStackTrace();
	    	System.out.print("Error occured Employee not deleted");
	    }
        
    }
}
