package com.mario.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.List;
import com.mario.main.entity.Task;
import com.mario.main.service.TaskService;

@SpringBootApplication
public class SpringJpaCrudApplication implements CommandLineRunner {

    @Autowired
    private TaskService service;

    public static void main(String[] args) {
        SpringApplication.run(SpringJpaCrudApplication.class, args);
    }

    @Override
    public void run(String... args) {

        //create 
//        Task t1 = new Task("Learn Spring Boot", "Spring Data JPA CRUD");
//        service.saveTask(t1);
//        System.out.println("Task Inserted");

        // read all
//        List<Task> tasks = service.getAllTasks();
//        tasks.forEach(t ->
//            System.out.println(t.getId() + " " + t.getTitle() + " " + t.getDescription())
//        );

        // read single by id
//        Task task = service.getTaskById(1L);
//        if (task != null) {
//            System.out.println(task.getTitle() + " " + task.getDescription());
//        } else {
//            System.out.println("Task Not Found");
//        }

        // update
//        Task updatedTask = new Task("Updated Title", "Updated Description");
//        service.updateTask(1L, updatedTask);
//        System.out.println("Task Updated");

        // delete
//        service.deleteTask(1L);
//        System.out.println("Task Deleted");
    }
}
