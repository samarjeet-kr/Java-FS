import React from 'react'
import AllTasks from './components/AllTasks'
import CreateTask from './components/CreateTask'
import EditTask from './components/EditTask'
import ErrorPage from './components/ErrorPage'
import Footer from './components/Footer'
import Navbar from './components/Navbar'
import TaskDetails from './components/TaskDetails'
import { Route, Routes } from 'react-router-dom'

const App = () => {
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path='/' element={<AllTasks/>} />
        <Route path='/create-task' element={<CreateTask/>} />
        <Route path='/task-details/:id' element={<TaskDetails/>} />
        <Route path='/edit-task/:id' element={<EditTask/>} />
        <Route path='*' element={<ErrorPage/>} />
      </Routes>
      <Footer/>
    </div>
  )
}

export default App
