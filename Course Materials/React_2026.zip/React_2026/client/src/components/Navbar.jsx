import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <div>
      <h2>To-Do-List</h2>
      <Link to='/' >All Tasks</Link>&nbsp;&nbsp;
      <Link to='/create-task' >Create Task</Link>
    </div>
  )
}

export default Navbar
