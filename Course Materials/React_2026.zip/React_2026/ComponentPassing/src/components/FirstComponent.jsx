// rafce - boilerplate will be generated for functional component 
import React from 'react'

const FirstComponent = () => {
  return (
    <div>
      <h1>First Component</h1>
    </div>
  )
}

export default FirstComponent
