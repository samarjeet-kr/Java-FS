import React from 'react'
import FirstComponent from './components/FirstComponent'
import SecondComponent from './components/SecondComponent'
import ThirdComponent from './components/ThirdComponent'

const App = () => {
  return (
    <div>
      <h1>Component Passing</h1>
      {/* <firstComponent /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements. */}
      {/* <firstComponent/> */}
      <FirstComponent/>
      <SecondComponent/>
      <ThirdComponent/>
    </div>
  )
}

export default App
