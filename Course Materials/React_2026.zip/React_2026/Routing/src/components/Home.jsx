import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <div>
      <h1>Welcome to React Routing</h1>
      <Link to='/first-page'>First Page</Link> &nbsp;&nbsp;
      <Link to='/second-page'>Second Page</Link> &nbsp;&nbsp;
      <Link to='/third-page'>Third Page</Link> &nbsp;&nbsp;
    </div>
  )
}

export default Home
