import React from 'react'
import { Link } from 'react-router-dom'

const ThirdPage = () => {
  return (
    <div>
      <h1>Third Page</h1>
      <Link to='/' >Back to home...</Link>
    </div>
  )
}

export default ThirdPage
