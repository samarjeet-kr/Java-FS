import React from 'react'
import FirstPage from './components/FirstPage'
import SecondPage from './components/SecondPage'
import ThirdPage from './components/ThirdPage'
import { Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import ErrorPage from './components/ErrorPage'

const App = () => {
  return (
    <div>
      <Routes>
        <Route path='/first-page' element={<FirstPage/>} />
        <Route path='/second-page' element={<SecondPage/>} />
        <Route path='/third-page' element={<ThirdPage/>} />
        <Route path='/' element={<Home/>} />
        <Route path='*' element={<ErrorPage/>} />
      </Routes>
    </div>
  )
}

export default App
