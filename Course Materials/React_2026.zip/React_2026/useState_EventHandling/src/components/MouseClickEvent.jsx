import React from 'react'
import { useState } from 'react'

const MouseClickEvent = () => {
  // count - initial state / current state
  // setCount - next state
  // useState(0) - we setting initial state of count as 0 
  const [count, setCount] = useState(0)

  const countPlus = () => {
    setCount(count + 1) // setting every next state after button click
  }
  const countMinus = () => {
    setCount(count - 1) // setting every next state after button click
  }
  const resetCount = () => {
    setCount(0) // setting every next state after button click
  }

  return (
    <div>
      <h2>Count: {count}</h2>
      <button onClick={countPlus} >Count +</button>
      <button onClick={countMinus} >Count -</button>
      <button onClick={resetCount} >Reset</button>
    </div>
  )
}

export default MouseClickEvent
