import React from 'react'
import { Routes, Route } from 'react-router-dom'
import MouseClickEvent from './components/MouseClickEvent'
import MouseOverEvent from './components/MouseOverEvent'
import FormSubmission from './components/FormSubmission'
import Home from './components/Home'

const App = () => {
  return (
    <div>
      <Routes>  
        <Route path='/' element={<Home/>}/>
        <Route path='/mouse-click-event' element={<MouseClickEvent/>} />
        <Route path='/mouse-over-event' element={<MouseOverEvent/>} />
        <Route path='/form-submission' element={<FormSubmission/>} />
      </Routes>
    </div>
  )
}

export default App
