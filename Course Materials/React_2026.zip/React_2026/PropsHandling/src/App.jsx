import React from 'react'
import Mario from './components/Mario'
import Shaun from './components/Shaun'

const App = () => {
  const str1 = "This page belongs to Mario"
  const str2 = "This page belongs to Shaun"
  return (
    <div>
      {/* Props is nothing but attributes of html elements and JSX functional Components */}
      <Mario str1={str1} />
      <Shaun str2={str2} />
    </div>
  )
}

export default App
