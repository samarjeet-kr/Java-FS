import React from 'react'
import Logo from './assets/react.svg'
import FirstComponent from './components/FirstComponent'
import SecondComponent from './components/SecondComponent'
import ThirdComponent from './components/ThirdComponent'

const App = () => {
  const name = "Mario"
  const age = 30
  const nums = [10, 20, 30, 40, 50]
  const link = "https://www.google.com"
  const target = "_blank"
  const title = "The Google"
  const alternative = "React Image"
  const ReactImage = () => {
    return <img src={Logo} alt={alternative} />
  }
  return (
    <div>
      <h2>Hello my name is {name} and age is {age}</h2>
      <h3>Numbers are {nums + " "}</h3>
      {nums.map((num) => (
        <ul>
          <li>{num}</li>
        </ul>
      ))}
      <a href={link} target={target} title={title}>Google</a>
      <img src={Logo} alt={alternative} />
      <ReactImage/>
      <FirstComponent/>
      <SecondComponent/>
      <ThirdComponent/>
    </div>
  )
}

export default App
