import React from 'react'

const SecondComponent = () => {
    return (
        <div>
            <h1 style={{
                color: "orangered",
                fontFamily: "calibri",
                fontSize: "30px",
                textAlign: "center",
                textShadow: "2px 2px 5px #f28585"
            }} >Second Component</h1>
        </div>
    )
}

export default SecondComponent
