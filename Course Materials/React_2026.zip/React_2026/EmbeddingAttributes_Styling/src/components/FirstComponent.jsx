import React from 'react'

const FirstComponent = () => {
  const firstStyle = {
    color: "crimson",
    fontFamily: "calibri",
    fontSize: "30px",
    textAlign: "center",
    textShadow: "2px 2px 5px #e47d7d"
  }
  return (
    <div>
      <h1 style={firstStyle} >First Component</h1>
    </div>
  )
}

export default FirstComponent
