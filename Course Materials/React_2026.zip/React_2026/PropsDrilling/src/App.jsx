import React from 'react'
import GrandParent from './components/GrandParent'

const App = () => {

  let str = "Virat Kohli is a cricketing icon, revered for his unparalleled run-scoring, aggressive leadership, and elite fitness standards, redefining modern cricket. With over 85 international centuries, he has secured his legacy as one of the game's greatest batsmen. His journey from a Delhi youngster to a global icon inspires millions, driven by intense passion and relentless discipline."

  return (
    <div>
      <GrandParent gprops={str} />
    </div>
  )
}

export default App
